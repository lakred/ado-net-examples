﻿namespace AirportExample.Models;

public class Plane
{
    public string PlaneType { get; set; }
    public int PassengerNumbers { get; set; }
    public int CargoQuantity { get; set; }
}